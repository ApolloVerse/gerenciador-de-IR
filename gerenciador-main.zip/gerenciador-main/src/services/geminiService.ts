import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function parseFinancialPDF(base64Data: string, fileName: string) {
  const model = "gemini-3-flash-preview";

  const systemInstruction = `
    Você é um especialista em documentos financeiros brasileiros e fiscalidade de IRPF. 
    Extraia dados estruturados de PDFs financeiros (extratos, informes, notas).
    
    Classifique cada ativo para o IRPF:
    - CNPJ da fonte emissora.
    - Grupo e Código IRPF.
    - Discriminação padrão.
  `;

  try {
    console.log(`Iniciando análise rápida do PDF: ${fileName} (${Math.round(base64Data.length / 1024)} KB)`);
    
    const response = await ai.models.generateContent({
      model,
      contents: [
        {
          parts: [
            { text: `Extraia dados deste PDF: "${fileName}"` },
            {
              inlineData: {
                mimeType: "application/pdf",
                data: base64Data
              }
            }
          ]
        }
      ],
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            institution: { type: Type.STRING, description: "Nome da instituição financeira" },
            documentType: { type: Type.STRING, enum: ["EXTRATO", "INFORME_RENDIMENTOS", "NOTA_CORRETAGEM"] },
            transactions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  ticker: { type: Type.STRING },
                  type: { type: Type.STRING, enum: ["COMPRA", "VENDA", "RENDIMENTO"] },
                  date: { type: Type.STRING, description: "Formato YYYY-MM-DD" },
                  quantity: { type: Type.NUMBER },
                  unitPrice: { type: Type.NUMBER },
                  totalValue: { type: Type.NUMBER },
                  costs: { type: Type.NUMBER },
                  irrf: { type: Type.NUMBER }
                }
              }
            },
            positions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  ticker: { type: Type.STRING },
                  name: { type: Type.STRING },
                  quantity: { type: Type.NUMBER },
                  averagePrice: { type: Type.NUMBER },
                  type: { type: Type.STRING, enum: ["ACAO", "FII", "ETF", "RENDA_FIXA", "CRIPTO"] },
                  cnpj: { type: Type.STRING, description: "CNPJ da fonte pagadora/emissora" },
                  irpfGroup: { type: Type.STRING, description: "Grupo do IRPF (ex: 03)" },
                  irpfCode: { type: Type.STRING, description: "Código do IRPF (ex: 31)" },
                  irpfDescription: { type: Type.STRING, description: "Discriminação completa para o IRPF" }
                }
              }
            },
            dividends: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  ticker: { type: Type.STRING },
                  amount: { type: Type.NUMBER },
                  date: { type: Type.STRING, description: "YYYY-MM-DD" },
                  type: { type: Type.STRING, enum: ["DIVIDENDO", "JCP", "RENDIMENTO"] },
                  isTaxable: { type: Type.BOOLEAN }
                }
              }
            }
          }
        }
      }
    });

    console.log("Resposta recebida do Gemini");

    if (!response.text) {
      console.error("Gemini retornou resposta vazia");
      throw new Error("Não foi possível processar o PDF.");
    }

    const cleanedText = response.text.trim();
    console.log("Texto extraído (parcial):", cleanedText.substring(0, 100));
    
    return JSON.parse(cleanedText);
  } catch (error) {
    console.error("Erro ao processar PDF com Gemini:", error);
    throw error;
  }
}
