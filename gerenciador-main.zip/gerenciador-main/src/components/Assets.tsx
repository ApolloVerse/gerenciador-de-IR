import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  ArrowUpDown, 
  MoreVertical, 
  ExternalLink,
  Loader2
} from 'lucide-react';
import { Asset } from '../types';
import { cn, formatCurrency, formatNumber } from '../lib/utils';
import { dbService } from '../services/dbService';
import { useAuth } from '../contexts/AuthContext';

export default function Assets() {
  const { user } = useAuth();
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('ALL');

  useEffect(() => {
    if (!user) return;
    
    setLoading(true);
    const unsubscribe = dbService.subscribeToAssets(user.uid, (data) => {
      setAssets(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const filteredAssets = assets.filter(asset => {
    const matchesSearch = asset.ticker.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          asset.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'ALL' || asset.type === filterType;
    return matchesSearch && matchesType;
  });

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="animate-spin text-emerald-500" size={40} />
        <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Carregando Ativos...</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col">
           <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">Consolidação de Ativos</h3>
           <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">B3, Crypto & Bens e Direitos</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={16} />
            <input 
              type="text" 
              placeholder="Buscar por ticker ou nome..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg text-sm w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-medium placeholder:text-slate-300"
            />
          </div>
          <div className="flex bg-white border border-slate-200 rounded-lg p-1">
            {['ALL', 'ACAO', 'FII', 'CRIPTO'].map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={cn(
                  "px-3 py-1 rounded-md text-[10px] font-black uppercase tracking-widest transition-all",
                  filterType === type 
                    ? "bg-slate-900 text-white shadow-lg" 
                    : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
                )}
              >
                {type === 'ALL' ? 'Todos' : type}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden flex flex-col min-h-[400px]">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 z-10">
              <tr>
                <th className="px-6 py-3">
                  <div className="flex items-center gap-2 text-[10px] font-black text-slate-500 uppercase tracking-widest">
                    Ticker / Ativo
                    <ArrowUpDown size={12} className="text-slate-300" />
                  </div>
                </th>
                <th className="px-6 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest">Tipo</th>
                <th className="px-6 py-3">
                  <div className="flex items-center justify-end gap-2 text-[10px] font-black text-slate-500 uppercase tracking-widest">
                    Qtd
                  </div>
                </th>
                <th className="px-6 py-3">
                   <div className="flex items-center justify-end gap-2 text-[10px] font-black text-slate-500 uppercase tracking-widest text-right">
                    P. Médio
                  </div>
                </th>
                <th className="px-6 py-3">
                  <div className="flex items-center justify-end gap-2 text-[10px] font-black text-slate-500 uppercase tracking-widest text-right">
                    Valor Atual
                  </div>
                </th>
                <th className="px-6 py-3">
                  <div className="flex items-center justify-end gap-2 text-[10px] font-black text-emerald-600 uppercase tracking-widest text-right">
                    Resultado %
                  </div>
                </th>
                <th className="px-6 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 uppercase font-mono text-[11px]">
              {filteredAssets.length > 0 ? filteredAssets.map((asset) => {
                const totalValue = asset.quantity * (asset.currentPrice || asset.averagePrice);
                const profit = ((asset.currentPrice || asset.averagePrice) - asset.averagePrice) / asset.averagePrice * 100;
                const isPositive = profit >= 0;

                return (
                  <tr key={asset.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-3 text-[11px]">
                      <div className="flex flex-col">
                        <span className="font-black text-slate-900 text-sm tracking-tight font-sans uppercase">{asset.ticker}</span>
                        <span className="text-[9px] text-slate-400 font-bold uppercase font-sans truncate max-w-[150px]">{asset.name || 'Ativo'}</span>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <span className={cn(
                        "text-[9px] font-black px-1.5 py-0.5 rounded tracking-widest border",
                        asset.type === 'ACAO' ? "bg-blue-50 text-blue-700 border-blue-100" :
                        asset.type === 'FII' ? "bg-orange-50 text-orange-700 border-orange-100" :
                        asset.type === 'CRIPTO' ? "bg-purple-50 text-purple-700 border-purple-100" :
                        "bg-slate-50 text-slate-700 border-slate-100"
                      )}>
                        {asset.type}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-right font-bold text-slate-700">
                      {formatNumber(asset.quantity, asset.type === 'CRIPTO' ? 8 : 2)}
                    </td>
                    <td className="px-6 py-3 text-right font-bold text-slate-400 italic">
                      {formatCurrency(asset.averagePrice)}
                    </td>
                    <td className="px-6 py-3 text-right font-black text-slate-900">
                      {formatCurrency(totalValue)}
                    </td>
                    <td className="px-6 py-3 text-right">
                      <span className={cn(
                        "font-black text-[11px] tracking-tight",
                        isPositive ? "text-emerald-600" : "text-rose-600"
                      )}>
                        {isPositive ? '+' : ''}{profit.toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-6 py-3 text-right">
                      <button className="p-1 text-slate-300 hover:text-slate-600 hover:bg-slate-100 rounded transition-all opacity-0 group-hover:opacity-100">
                        <MoreVertical size={16} />
                      </button>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={7} className="px-6 py-20 text-center text-slate-400 font-bold uppercase tracking-widest text-[11px]">
                    Nenhum ativo encontrado em sua carteira.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        <div className="bg-slate-900 p-2 px-6 flex items-center justify-between mt-auto">
           <div className="flex items-center gap-2">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                Interface de Alta Densidade Sincronizada • B3 CONNECTED
              </span>
           </div>
           <span className="text-[10px] text-slate-500 font-bold uppercase">Replicação Receita Federal v.2.4.0</span>
        </div>
      </div>
    </div>
  );
}
