import React, { useEffect, useState } from 'react';
import { 
  FileText, 
  Download, 
  Printer,
  ChevronDown,
  Building2,
  Info,
  ArrowRight,
  Loader2
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { dbService } from '../services/dbService';
import { useAuth } from '../contexts/AuthContext';
import { Asset } from '../types';

export default function IRReport() {
  const { user } = useAuth();
  const [assets, setAssets] = useState<Asset[]>([]);
  const [dividends, setDividends] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      let assetsLoaded = false;
      let dividendsLoaded = false;

      const unsubAssets = dbService.subscribeToAssets(user.uid, (data) => {
        setAssets(data);
        assetsLoaded = true;
        if (dividendsLoaded) setLoading(false);
      });
      const unsubDividends = dbService.subscribeToDividends(user.uid, (data) => {
        setDividends(data);
        dividendsLoaded = true;
        if (assetsLoaded) setLoading(false);
      });

      // Timeout as safety measure
      const timeout = setTimeout(() => {
        setLoading(false);
      }, 5000);

      return () => {
        unsubAssets();
        unsubDividends();
        clearTimeout(timeout);
      };
    }
  }, [user]);

  const totalAssets = assets.reduce((acc, curr) => acc + (curr.quantity * curr.averagePrice), 0);
  const totalDividends = dividends.reduce((acc, curr) => acc + (curr.amount || 0), 0);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 grayscale opacity-50">
        <Loader2 className="animate-spin text-emerald-500" size={40} />
        <span className="text-[10px] font-black uppercase tracking-[0.3em] mt-4">Consolidando Relatório Fiscal</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex flex-col">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">Relatório Auxiliar de IRPF 2025</h3>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Conforme Leiaute do Programa Gerador de Declaração (PGD)</span>
        </div>
        <div className="flex gap-2">
           <button className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 text-slate-600 rounded text-[10px] font-bold uppercase tracking-widest hover:bg-slate-50 transition-all">
              <Printer size={14} />
              Imprimir
           </button>
           <button className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded text-[10px] font-black uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg">
             <Download size={14} />
             Exportar Relatório
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <ReportSection 
          title="Bens e Direitos" 
          amount={totalAssets} 
          items={assets.length} 
          active 
        />
        <ReportSection 
          title="Rends. Isentos" 
          amount={totalDividends} 
          items={dividends.length} 
        />
        <ReportSection title="Ganhos de Capital" amount={0} items={0} />
        <ReportSection title="Dívidas e Ônus" amount={0} items={0} />
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* Section: Bens e Direitos */}
        <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden flex flex-col">
          <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-slate-900 flex items-center justify-center text-white font-black text-[10px]">01</div>
                <h4 className="text-[11px] font-black text-slate-700 uppercase tracking-widest">Bens e Direitos</h4>
             </div>
             <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest italic">Grupo Principal - Participações Societárias</span>
          </div>

          <div className="overflow-x-auto">
             <table className="w-full text-left border-collapse">
                <thead className="bg-slate-50/50 text-[9px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
                   <tr>
                      <th className="px-6 py-3 w-24">Código</th>
                      <th className="px-6 py-3">Discriminação Detalhada</th>
                      <th className="px-6 py-3 text-right">Situação 31/12/2023</th>
                      <th className="px-6 py-3 text-right text-emerald-700 bg-emerald-50/20">Situação 31/12/2024</th>
                   </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-[11px]">
                   {assets.length > 0 ? assets.map((asset) => (
                      <tr key={asset.id} className="hover:bg-slate-50/50 transition-colors group">
                         <td className="px-6 py-5">
                            <div className="flex flex-col gap-1">
                               <span className="font-mono font-black text-slate-900 bg-slate-100 px-2 py-1 rounded text-center w-fit border border-slate-200">
                                 {asset.irpfCode || '31'}
                               </span>
                               <span className="text-[8px] text-slate-400 font-bold uppercase tracking-tighter">Grupo: {asset.irpfGroup || '03'}</span>
                            </div>
                         </td>
                         <td className="px-6 py-5">
                            <p className="font-black text-slate-800 uppercase tracking-tight mb-1">{asset.ticker} - {asset.name}</p>
                            <div className="bg-slate-50/50 border border-slate-100 p-3 rounded text-[10px] text-slate-500 leading-relaxed font-sans italic">
                               {asset.irpfDescription || `${asset.quantity} COTAS DE ${asset.name.toUpperCase()} (${asset.ticker}) ADQUIRIDAS PELO VALOR TOTAL DE ${formatCurrency(asset.quantity * asset.averagePrice)}. CUSTODIADO NA INSTITUIÇÃO ${asset.institution.toUpperCase()}.${asset.cnpj ? ` CNPJ DA FONTE PAGADORA: ${asset.cnpj}` : ''}`}
                            </div>
                         </td>
                         <td className="px-6 py-5 text-right text-slate-400 font-mono italic">R$ 0,00</td>
                         <td className="px-6 py-5 text-right text-slate-900 font-mono font-black border-l border-slate-50 group-hover:bg-emerald-50/10">
                            {formatCurrency(asset.quantity * asset.averagePrice)}
                         </td>
                      </tr>
                   )) : (
                    <tr>
                      <td colSpan={4} className="px-6 py-10 text-center text-slate-400 uppercase text-[10px] font-bold tracking-widest">
                        Nenhum ativo importado para o ano base.
                      </td>
                    </tr>
                   )}
                </tbody>
             </table>
          </div>
        </div>

        {/* Info Box */}
        <div className="p-5 bg-white border border-slate-200 rounded-lg shadow-sm flex items-start gap-4">
           <div className="p-2 bg-emerald-50 rounded text-emerald-600">
              <Info size={18} />
           </div>
           <div>
              <h5 className="text-[11px] font-black text-slate-800 uppercase tracking-tight mb-1">Como integrar com o PGD IRPF?</h5>
              <p className="text-[10px] text-slate-500 leading-relaxed font-medium">
                Os dados exibidos são extraídos automaticamente via Inteligência Artificial dos PDFs importados. 
                Cada item na tabela corresponde a um registro de "Bens e Direitos". Verifique os códigos e CNPJs antes de finalizar sua declaração oficial.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}

function ReportSection({ title, amount, items, active }: any) {
  return (
    <div className={cn(
      "p-4 bg-white border rounded-lg shadow-sm group cursor-pointer transition-all",
      active ? "border-emerald-500 ring-2 ring-emerald-500/10" : "border-slate-200 hover:border-slate-300"
    )}>
      <div className="flex items-center justify-between mb-2">
         <span className={cn(
           "text-[9px] font-black uppercase tracking-[0.2em]",
           active ? "text-emerald-600" : "text-slate-400"
         )}>{title}</span>
         <ArrowRight size={10} className={active ? "text-emerald-500" : "text-slate-300"} />
      </div>
      <p className="text-lg font-black text-slate-950 tracking-tight">{formatCurrency(amount)}</p>
      <p className="text-[9px] text-slate-400 font-bold uppercase mt-1 tracking-widest">{items} ITENS PROCESSADOS</p>
    </div>
  );
}
