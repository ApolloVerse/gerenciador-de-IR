import React, { useState, useEffect } from 'react';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Download,
  Filter,
  Loader2
} from 'lucide-react';
import { cn, formatCurrency, formatNumber } from '../lib/utils';
import { dbService } from '../services/dbService';
import { useAuth } from '../contexts/AuthContext';
import { Transaction } from '../types';

export default function Transactions() {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    const unsubscribe = dbService.subscribeToTransactions(user.uid, (data) => {
      setTransactions(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, [user]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="animate-spin text-emerald-500" size={40} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex flex-col">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">Histórico de Operações</h3>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Sincronizado com Notas de Corretagem</span>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 rounded text-slate-500 font-bold text-[10px] uppercase tracking-widest hover:bg-slate-50 transition-all">
            <Filter size={14} />
            Filtrar
          </button>
          <button className="flex items-center gap-2 px-3 py-1.5 bg-slate-900 text-white rounded text-[10px] font-bold uppercase tracking-widest hover:bg-slate-800 transition-all">
            <Download size={14} />
            Exportar CSV
          </button>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 text-[10px] font-black text-slate-500 uppercase tracking-widest border-b border-slate-100">
              <tr>
                <th className="px-6 py-3">Data</th>
                <th className="px-6 py-3">Ativo</th>
                <th className="px-6 py-3">Tipo</th>
                <th className="px-6 py-3 text-right">Qtd</th>
                <th className="px-6 py-3 text-right">Preço Un.</th>
                <th className="px-6 py-3 text-right">Total</th>
                <th className="px-6 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 text-[11px] font-mono">
              {transactions.length > 0 ? transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-3 text-nowrap text-slate-400 font-bold uppercase">
                    {new Date(tx.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
                  </td>
                  <td className="px-6 py-3">
                    <span className="font-black text-slate-900 font-sans text-sm uppercase">{tx.ticker || 'ATIVO'}</span>
                  </td>
                  <td className="px-6 py-3">
                    <span className={cn(
                      "text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-widest",
                      tx.type === 'COMPRA' ? "bg-blue-50 text-blue-600 border border-blue-100" :
                      tx.type === 'VENDA' ? "bg-orange-50 text-orange-600 border border-orange-100" :
                      "bg-emerald-50 text-emerald-600 border border-emerald-100"
                    )}>
                      {tx.type}
                    </span>
                  </td>
                  <td className="px-6 py-3 text-right font-bold text-slate-700">
                    {formatNumber(tx.quantity, tx.ticker === 'Bitcoin' ? 8 : 2)}
                  </td>
                  <td className="px-6 py-3 text-right text-slate-400">
                    {formatCurrency(tx.unitPrice)}
                  </td>
                  <td className="px-6 py-3 text-right font-black text-slate-900">
                    {formatCurrency(tx.totalValue)}
                  </td>
                  <td className="px-6 py-3 text-right">
                    <button className="p-1 text-slate-200 hover:text-slate-400 transition-colors opacity-0 group-hover:opacity-100">
                      <ArrowUpRight size={14} />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={7} className="text-center py-20 text-slate-400 font-bold uppercase tracking-widest text-[10px]">
                    Nenhuma operação processada ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
