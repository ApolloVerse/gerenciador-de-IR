import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { 
  FileUp, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  X,
  Plus,
  Upload,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, formatCurrency } from '../lib/utils';
import { parseFinancialPDF } from '../services/geminiService';
import { dbService } from '../services/dbService';
import { useAuth } from '../contexts/AuthContext';
import { processMonthlyTaxes, getDARFCode } from '../lib/finance';

interface UploadStatus {
  file: File;
  status: 'idle' | 'processing' | 'completed' | 'error';
  progress: number;
  message?: string;
  result?: any;
}

export default function PDFUpload({ onComplete }: { onComplete: () => void }) {
  const { user } = useAuth();
  const [uploads, setUploads] = useState<UploadStatus[]>([]);
  const [isSaving, setIsSaving] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newUploads = acceptedFiles.map(file => ({
      file,
      status: 'idle' as const,
      progress: 0,
    }));
    setUploads(prev => [...prev, ...newUploads]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    multiple: true
  } as any);

  const removeUpload = (index: number) => {
    setUploads(prev => prev.filter((_, i) => i !== index));
  };
  
  const handleConfirm = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      const allTxToSave: any[] = [];
      
      for (const upload of uploads) {
        if (upload.status === 'completed' && upload.result) {
          const { positions, transactions, institution } = upload.result;
          
          // Save Assets
          if (positions) {
            for (const pos of positions) {
              await dbService.upsertAsset(user.uid, {
                ...pos,
                institution: institution || 'Desconhecida'
              });
            }
          }
          
          // Collect Transactions
          if (transactions) {
            for (const tx of transactions) {
              allTxToSave.push({
                ...tx,
                userId: user.uid
              });
            }
          }

          // Save Dividends
          if (upload.result.dividends) {
            for (const div of upload.result.dividends) {
              await dbService.addDividend(user.uid, div);
            }
          }
        }
      }

      // Save Transactions
      for (const tx of allTxToSave) {
        await dbService.addTransaction(user.uid, tx);
      }

      // Recalculate DARFs based on the new data
      const currentAssets = await dbService.getAssets(user.uid);
      const taxResults = processMonthlyTaxes(allTxToSave, currentAssets);

      for (const res of taxResults) {
        // Simplified due date: last business day of next month
        const dueDate = new Date(res.year, res.month, 0).toISOString().split('T')[0];

        await dbService.addDARF(user.uid, {
          userId: user.uid,
          month: res.month,
          year: res.year,
          amount: res.tax,
          status: 'PENDENTE',
          assetType: res.assetType,
          code: getDARFCode(res.assetType),
          dueDate: dueDate
        });
      }

      onComplete();
    } catch (error) {
      console.error("Erro ao salvar dados:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const processFile = async (index: number) => {
    const upload = uploads[index];
    if (upload.status === 'processing' || upload.status === 'completed') return;

    setUploads(prev => {
      const next = [...prev];
      next[index].status = 'processing';
      next[index].message = 'IA analisando documento (isso pode levar 30s)...';
      return next;
    });

    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const base64 = (reader.result as string).split(',')[1];
          resolve(base64);
        };
        reader.onerror = () => reject(new Error("Erro ao ler o arquivo localmente."));
      });
      reader.readAsDataURL(upload.file);
      const base64 = await base64Promise;

      const result = await parseFinancialPDF(base64, upload.file.name);
      
      console.log("Resultado da extração:", result);

      setUploads(prev => {
        const next = [...prev];
        next[index].status = 'completed';
        next[index].result = result;
        next[index].message = 'Análise Concluída';
        return next;
      });
    } catch (error: any) {
      console.error("Erro no processamento do arquivo:", error);
      setUploads(prev => {
        const next = [...prev];
        next[index].status = 'error';
        next[index].message = error.message || 'Erro no processamento.';
        return next;
      });
    }
  };

  const processAll = async () => {
    for (let i = 0; i < uploads.length; i++) {
      if (uploads[i].status === 'idle') {
        await processFile(i);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">Importação de Documentos</h3>
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Leitor Universal de Notas de Corretagem e Extratos</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 space-y-4">
          <div 
            {...getRootProps()} 
            className={cn(
              "bg-white border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all min-h-[280px]",
              isDragActive ? "border-emerald-500 bg-emerald-50/30" : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
            )}
          >
            <input {...getInputProps()} />
            <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mb-4 text-slate-400">
              <Upload size={28} />
            </div>
            <p className="text-[11px] font-black text-slate-800 uppercase tracking-tight mb-1">Arraste seus comprovantes</p>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-relaxed">PDFs de corretoras, bancos ou exchanges</p>
          </div>

          <div className="bg-slate-900 rounded-lg p-4 border border-slate-800">
             <div className="flex items-center gap-3 mb-2">
                <div className="w-6 h-6 rounded bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                   <AlertCircle size={14} />
                </div>
                <h4 className="text-[9px] font-black text-white uppercase tracking-widest">Privacidade</h4>
             </div>
             <p className="text-[10px] text-slate-500 leading-relaxed">
                Dados processados localmente e via IA dedicada. Segregação total de informações pessoais.
             </p>
          </div>
        </div>

        <div className="lg:col-span-8 flex flex-col min-h-[400px]">
          <div className="bg-white border border-slate-200 rounded-lg shadow-sm flex-1 flex flex-col overflow-hidden">
             <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Fila de Processamento</span>
                {uploads.length > 0 && (
                   <button 
                    onClick={processAll}
                    disabled={uploads.every(u => u.status === 'completed' || u.status === 'processing')}
                    className="text-[10px] font-black text-emerald-600 hover:text-emerald-700 uppercase tracking-widest flex items-center gap-2 disabled:opacity-30"
                   >
                     <Plus size={12} />
                     Processar Tudo
                   </button>
                )}
             </div>

             <div className="flex-1 overflow-y-auto custom-scrollbar p-0">
                <AnimatePresence>
                  {uploads.length > 0 ? (
                    <div className="divide-y divide-slate-50">
                      {uploads.map((upload, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="p-4 flex items-center justify-between group hover:bg-slate-50/50 transition-colors"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded bg-slate-100 flex items-center justify-center text-slate-400 shrink-0">
                              <FileText size={18} />
                            </div>
                            <div className="flex flex-col">
                              <span className="text-[11px] font-black text-slate-800 uppercase truncate max-w-[200px]">{upload.file.name}</span>
                              <span className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{upload.message || 'Aguardando ação'}</span>
                              {upload.status === 'completed' && upload.result && (
                                <div className="mt-1 flex gap-2">
                                   {upload.result.positions?.length > 0 && (
                                     <span className="text-[8px] bg-emerald-50 text-emerald-600 px-1 rounded font-black uppercase">
                                       {upload.result.positions.length} Ativos
                                     </span>
                                   )}
                                   {upload.result.transactions?.length > 0 && (
                                     <span className="text-[8px] bg-slate-100 text-slate-600 px-1 rounded font-black uppercase">
                                       {upload.result.transactions.length} Transações
                                     </span>
                                   )}
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-4">
                             {upload.status === 'completed' && (
                               <button 
                                 onClick={() => console.log('Extracted Data:', upload.result)} 
                                 className="text-[9px] font-black text-slate-400 hover:text-emerald-500 uppercase tracking-widest border border-slate-100 px-2 py-0.5 rounded"
                               >
                                 Log Data
                               </button>
                             )}
                             {upload.status === 'idle' && (
                               <button onClick={() => processFile(idx)} className="p-2 text-slate-400 hover:text-emerald-500 transition-colors">
                                  <Plus size={16} />
                               </button>
                             )}
                             {upload.status === 'processing' && <Loader2 size={16} className="animate-spin text-emerald-500" />}
                             {upload.status === 'completed' && <CheckCircle2 size={16} className="text-emerald-500" />}
                             
                             <button onClick={() => removeUpload(idx)} className="p-2 text-slate-300 hover:text-rose-500 transition-colors">
                                <X size={16} />
                             </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-slate-300 py-20 grayscale opacity-50">
                       <Database size={40} strokeWidth={1} />
                       <span className="text-[10px] font-black uppercase tracking-[0.3em] mt-4">Nenhum Documento Pendente</span>
                    </div>
                  )}
                </AnimatePresence>
             </div>

             {uploads.some(u => u.status === 'completed') && (
                <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
                   <button 
                    onClick={handleConfirm}
                    disabled={isSaving}
                    className="px-6 py-2 bg-slate-900 text-white font-black text-[10px] uppercase tracking-widest rounded hover:bg-slate-800 transition-all flex items-center gap-2 shadow-xl"
                   >
                     {isSaving ? <Loader2 size={12} className="animate-spin" /> : <CheckCircle2 size={12} />}
                     Efetivar Lote na Carteira
                   </button>
                </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
}
