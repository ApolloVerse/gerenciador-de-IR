import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Wallet, 
  ArrowUpRight, 
  ArrowDownRight,
  PieChart as PieChartIcon,
  BarChart as BarChartIcon,
  Loader2
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { formatCurrency, formatNumber } from '../lib/utils';
import { dbService } from '../services/dbService';
import { useAuth } from '../contexts/AuthContext';
import { Asset } from '../types';

const data = [
  { name: 'Jan', value: 45000 },
  { name: 'Fev', value: 48500 },
  { name: 'Mar', value: 47000 },
  { name: 'Abr', value: 52000 },
  { name: 'Mai', value: 55600 },
  { name: 'Jun', value: 58000 },
  { name: 'Jul', value: 62000 },
  { name: 'Ago', value: 66453 },
];

export default function Dashboard() {
  const { user } = useAuth();
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetch = async () => {
      try {
        const data = await dbService.getAssets(user.uid);
        setAssets(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [user]);

  const totalEquity = assets.reduce((acc, asset) => acc + (asset.quantity * (asset.currentPrice || asset.averagePrice)), 0);
  
  const portfolioDistribution = [
    { name: 'Ações', value: Math.round((assets.filter(a => a.type === 'ACAO').length / assets.length * 100) || 0), color: '#10b981' }, // Emerald
    { name: 'FIIs', value: Math.round((assets.filter(a => a.type === 'FII').length / assets.length * 100) || 0), color: '#334155' }, // Slate 700
    { name: 'Renda Fixa', value: Math.round((assets.filter(a => a.type === 'RENDA_FIXA').length / assets.length * 100) || 0), color: '#64748b' }, // Slate 500
    { name: 'Outros', value: Math.round((assets.filter(a => !['ACAO', 'FII', 'RENDA_FIXA'].includes(a.type)).length / assets.length * 100) || 0), color: '#94a3b8' }, // Slate 400
  ].filter(p => p.value > 0);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="animate-spin text-emerald-500" size={40} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard 
          title="Patrimônio Total" 
          value={totalEquity} 
          change={12.5} 
          icon={Wallet} 
          isPositive={true}
        />
        <MetricCard 
          title="Resultado (Mês)" 
          subValue="Swing Trade / Ações"
          value={totalEquity * 0.05} 
          change={8.2} 
          icon={TrendingUp} 
          isPositive={true}
        />
        <MetricCard 
          title="Dividendos (Mês)" 
          subValue="Proventos Acumulados"
          value={totalEquity * 0.008} 
          change={-2.1} 
          icon={ArrowUpRight} 
          isPositive={false}
        />
        <MetricCard 
          title="DARF Pendente" 
          subValue="Vencimento: 30/05"
          value={0} 
          change={0} 
          icon={PieChartIcon} 
          isPositive={true}
          danger={true}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Evolution Chart */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-lg p-6 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div className="flex flex-col">
               <h3 className="text-sm font-bold text-slate-700 uppercase tracking-tight">Evolução do Patrimônio</h3>
               <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-none mt-1">Consolidado Multicorretora</span>
            </div>
            <select className="bg-slate-50 border border-slate-200 rounded text-[11px] font-bold px-3 py-1 text-slate-600 outline-none hover:bg-slate-100 transition-colors uppercase">
              <option>Últimos 12 meses</option>
              <option>Todo o período</option>
            </select>
          </div>
          <div className="h-[320px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                  tickFormatter={(v) => `R$ ${v/1000}k`}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
                  labelStyle={{ fontWeight: 800, color: '#1e293b', marginBottom: '4px', textTransform: 'uppercase', fontSize: '10px' }}
                  itemStyle={{ fontSize: '12px', fontWeight: 700 }}
                  formatter={(value: any) => [formatCurrency(value), 'Patrimônio']}
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorValue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Distribution Chart */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-lg p-6 shadow-sm flex flex-col">
          <h3 className="text-sm font-bold text-slate-700 uppercase tracking-tight mb-8">Alocação Estratégica</h3>
          <div className="h-[220px] w-full relative flex-1">
            {portfolioDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={portfolioDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={75}
                    paddingAngle={4}
                    dataKey="value"
                    stroke="none"
                  >
                    {portfolioDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
                <div className="flex items-center justify-center h-full text-slate-400 text-xs font-bold uppercase tracking-widest">Sem ativos</div>
            )}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-xl font-extrabold text-slate-800">100%</span>
              <span className="text-[9px] text-slate-400 uppercase font-black tracking-[0.2em] leading-none mt-1">Sincronizado</span>
            </div>
          </div>
          <div className="mt-8 space-y-2.5">
            {portfolioDistribution.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-[11px] font-bold">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-[2px]" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-500 uppercase tracking-tight">{item.name}</span>
                </div>
                <span className="text-slate-900">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, change, subValue, icon: Icon, isPositive, danger }: any) {
  return (
    <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm group transition-all hover:bg-slate-50">
      <div className="flex justify-between items-start mb-2">
        <div className="flex flex-col">
           <p className={cn(
             "text-[10px] uppercase font-bold tracking-wider leading-none mb-1",
             danger ? "text-orange-600" : "text-slate-500"
           )}>{title}</p>
           <h4 className={cn(
             "text-xl font-black tracking-tight",
             danger ? "text-orange-600" : "text-slate-950"
           )}>{formatCurrency(value)}</h4>
        </div>
        {!danger && (
          <div className={cn(
            "flex items-center gap-0.5 text-[10px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter",
            isPositive ? "text-emerald-700 bg-emerald-100" : "text-rose-700 bg-rose-100"
          )}>
            {isPositive ? <ArrowUpRight size={10} strokeWidth={3} /> : <ArrowDownRight size={10} strokeWidth={3} />}
            {change}%
          </div>
        )}
      </div>
      <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-50">
         <span className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">{subValue || 'Atualizado em tempo real'}</span>
         <Icon className="text-slate-200 group-hover:text-slate-400 transition-colors" size={12} />
      </div>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
